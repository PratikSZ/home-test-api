
---

## 🚀 How to Build and Run

### 🔧 Prerequisites

- Java 17 or higher (this project uses JDK 21)
- Maven 3.6+
- IntelliJ IDEA or any Java IDE


git clone https://github.com/your-username/api-automation.git
cd api-automation
to run tests
mvn clean install

1)to run all tests-mvn test

2)to run specific sceanrios using tags - mvn test -Dcucumber.filter.tags="@testcase1"

3)to run from intellij -
Open the project in IntelliJ IDEA
Navigate to the runner class under runners/ package (e.g., RunCucumberTests.java)
Right-click and select Run 'RunCucumberTests'


