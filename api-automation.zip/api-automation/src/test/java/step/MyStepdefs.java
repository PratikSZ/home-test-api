package step;
import io.cucumber.java.en.*;
import io.restassured.response.Response;
import org.junit.Assert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
public class MyStepdefs {
    @Given("Inventory API is UP")
    public void inventoryAPIIsUP() {
        baseURI = "http://localhost:3100/";
    }

    public static Response response;
    public Map<String, String> requestBody = new HashMap<>();
    public String id;
    @When("user requests inventory list")
    public void userRequestsInventoryList() {
        response = given().
                when().get("api/inventory").
                then().extract().response();
    }

    @Then("user verifies the status code should be {int}")
    public void userVerifiesTheStatusCodeShouldBe(int expectedStatusCode) {
        Assert.assertEquals(expectedStatusCode, response.getStatusCode());
    }

    @And("verify response contains {int} items")
    public void verifyResponseContainsItems(int itemcount) {
        List<Object> items = response.jsonPath().getList("data");
        Assert.assertEquals("Item count mismatch", itemcount, items.size());
    }
    public void checkFields(String... expectedFields) {
        //variable length args
        List<Map<String, Object>> items = response.jsonPath().getList("data");
        for (int i = 0; i < items.size(); i++) {
            Map<String, Object> item = items.get(i);
            for (String field : expectedFields) {
                Assert.assertTrue("Missing field '" + field + "' in item at index " + i, item.containsKey(field));
//                System.out.println("item"+item);
//                System.out.println(field);
            }
        }
    }

    @And("every item has {string},{string},{string},{string}, fields")
    public void everyItemHasFields(String id, String name, String price, String image) {
        checkFields(id, name, price, image);
        }

    @When("user requests inventory list for id {int}")
    public void userRequestsInventoryListForId(int id) {
        response = given().
                when().get("api/inventory/filter?id="+id).
                then().extract().response();
    }

    @And("verify response contains correct details for id {int}")
    public void verifyResponseContainsCorrectDetailsForId(int id) {
        Assert.assertEquals(response.getBody().jsonPath().get("id").toString(),String.valueOf(id));
        Assert.assertEquals("Baked Rolls x 8",response.getBody().jsonPath().get("name").toString());
        Assert.assertEquals("roll.png",response.getBody().jsonPath().get("image").toString());
        Assert.assertEquals("$10",response.getBody().jsonPath().get("price").toString());
        //System.out.println("ENDING................");
    }

    @When("user passes inventory details with {string} ,{string},{string}")
    public void userPassesInventoryDetailsWith(String name, String image, String price) {
        requestBody.put("name", name);
        requestBody.put("image", image);
        requestBody.put("price", price);
    }

    @And("for the {string}")
    public void forThe(String id_type) {
        if (id_type.equalsIgnoreCase("existant")) {
            id = "10";
        } else {
            id = String.valueOf((int)(Math.random() * 9000) + 1000);
        }
        requestBody.put("id", id);
        response = given()
                .header("Content-Type", "application/json")
                .body(requestBody)
                .when()
                .post("http://localhost:3100/api/inventory/add");
        System.out.println("for id "+id);
    }

    @Then("Verify the status code is {string}")
    public void verifyTheStatusCodeIs(String statusCode) {
        Assert.assertEquals(statusCode, String.valueOf(response.getStatusCode()));
    }

    @And("User hits the API")
    public void userHitsTheAPI() {
        response = given()
                .header("Content-Type", "application/json")
                .body(requestBody)
                .when()
                .post("http://localhost:3100/api/inventory/add")
                .then().extract().response();
    }

    @And("Verify response message is {string}")
    public void verifyResponseMessageIs(String expectedResponseMessage) {
        Assert.assertEquals(expectedResponseMessage,response.getBody().asString());
    }

    @And("verify response contains correct details {string} ,{string},{string}")
    public void verifyResponseContainsCorrectDetails(String name, String image, String price) {
        Assert.assertEquals(id.toString(),String.valueOf(id));
        Assert.assertEquals(name,response.getBody().jsonPath().get("name").toString());
        Assert.assertEquals(image,response.getBody().jsonPath().get("image").toString());
        Assert.assertEquals(price,response.getBody().jsonPath().get("price").toString());
    }

    @When("user requests inventory details for same entry")
    public void userRequestsInventoryDetailsForSameEntry() {
        response = given().
                when().get("api/inventory/filter?id="+id).
                then().extract().response();
    }
}
    //mvn clean test '-Dcucumber.filter.tags="@testcase1"'
//mvn test '-Dcucumber.filter.tags="@api"'